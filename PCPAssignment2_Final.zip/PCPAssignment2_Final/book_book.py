#!/usr/bin/env python
# coding: utf-8

# In[83]:


import pandas as pd
import Similarities as sm
class BookSim:
    def __init__(self):
        self.sim = sm.Similarity()
    def set_isbn(self,tbook):
        self.tbook = tbook
    def set_dataframe(self,getData):
        self.df = getData
    def getBookDF(self):
        #target_ book = getData. Loc[getData['ISBN' ] == self.tbook]['Book-Rating'].to_List()
        target_book = self.df[self.df ['ISBN']== self.tbook]
        self.target_book = target_book
        return target_book
    def getGroupedbyBooks(self):
        related_users = self.df[self.df['User-ID'].isin(self.target_book['User-ID'].tolist())]
        related_users = related_users.loc[related_users['ISBN'] != self.tbook]
        grouped_books = related_users.groupby('ISBN')
        return grouped_books
    def set_similarity(self,similarity_):
        self.sim = sm.Similarity()
        self.__similarity_ = similarity_
    def set_threshhold(self,threshold):
        self.threshhold = threshold
    def get_book_similarity(self):
        self.getBookDF()
        book_sim = {}
        for u,items in self.getGroupedbyBooks():
            print(u)
            targetbook_df=self.target_book[self.target_book['User-ID'].isin(items['User-ID'].tolist())]
            targets_rating = targetbook_df['Book-Rating'].tolist()
            relation_ratings = items['Book-Rating'].tolist()
            if len(targets_rating) > 2:
                if(sum(targets_rating) > 0 and sum(relation_ratings) > 0):
                    self.sim.set_values(targets_rating,relation_ratings)
                    corr_relationship = self.similarity_func()
#                     print("corr_relationship : ",corr_relationship)
                    if(corr_relationship !="invalid_similarity"):
                        book_sim[u] = corr_relationship
        return book_sim
    def sort_and_present(self):
        bkdict = self.get_book_similarity()
        if(len(bkdict) < 1) :
            return "No similarity between users"
        else:
            correlation_df = pd.DataFrame.from_dict(bkdict, orient='index')
            correlation_df = correlation_df.sort_values([0], ascending=[False])
            return correlation_df.head(self.threshhold)
        
    def similarity_func(self):
        if self.__similarity_ == "squared_euclidean_similarity":
            return self.sim.squared_euclidean_similarity()
        elif self.__similarity_ == "minkowski_distance_similarity":
            return self.sim.minkowski_distance_similarity()
        elif self.__similarity_ == "hamming_distance_similarity":
            return self.sim.hamming_distance_similarity()
        elif self.__similarity_ == "cosine_similarity":
            return self.sim.cosine_similarity()
        elif self.__similarity_ == "spearman_correlation_similarity":
            return self.sim.spearman_correlation_similarity()
        elif self.__similarity_ == "pearson_correlation":
            return self.sim.pearson_correlation()
        elif self.__similarity_ == "chebyshev_similarity":
            return self.sim.chebyshev_similarity()
        else:
            return "invalid_similarity"
   
    def setBook1(self, user):
        self.user = user
    def getBook1(self):
        return self.user

