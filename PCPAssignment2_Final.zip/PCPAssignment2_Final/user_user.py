#!/usr/bin/env python
# coding: utf-8

# In[4]:


import Dataset_Module as dm
import Similarities as sm
import pandas as pd

class test_Module():
    #init is a constructor (to create new object)
    def __init__(self,):
        self.__books_dataset = None
        self.__users_dataset = None
        self.__ratings_dataset = None
    def set_datasets(self,books,ratings,users):
        self.__books_dataset = books
        self.__users_dataset = users
        self.__ratings_dataset = ratings
    def set_similarity(self,similarity_):
        self.sim = sm.Similarity()
        self.__similarity_ = similarity_
    def set_set_user(self,userid):
         self.__userid = userid
    def set_dataframe(self,df):
        self.mergerdataframe = df
    def loaddataset(self):
        mergerdataframe=dm.Loaddata( self.__books_dataset,self.__ratings_dataset,self.__users_dataset)
        self.mergerdataframe = mergerdataframe.mergedataset()
        return mergerdataframe.mergedataset()
    def obtaintarget_user_df(self):

        return self.mergerdataframe.loc[self.mergerdataframe['User-ID'] == self.__userid]
    def obtain_common_users(self):

        target_user_df = self.obtaintarget_user_df()
        tem = self.mergerdataframe.loc[self.mergerdataframe['ISBN'].isin(target_user_df['ISBN'].tolist())]
        return tem.loc[tem['User-ID'] != self.__userid]
    def set_values(self,x,y):
         self.sim.set_values(x,y) 
    def cal_similarusers_sim(self):
        sim_users_df = self.obtain_common_users()
        groupbysimuser=sim_users_df.groupby(['User-ID'])
        correlation_arr = {}
        target_user_df = self.obtaintarget_user_df()
        sim = sm.Similarity()
        for user,grop_data in groupbysimuser:
            new_grop_data = target_user_df[target_user_df['ISBN'].isin(grop_data['ISBN'].tolist())]
            xtargetdata = new_grop_data['Book-Rating'].tolist()
            new_grop_data1 = grop_data[grop_data['ISBN'].isin(target_user_df['ISBN'].tolist())]
            yneigbourData = new_grop_data1['Book-Rating'].tolist()
            if(len(xtargetdata) > 1):
                if(sum(xtargetdata) > 1 and sum(yneigbourData)>1):
                    self.sim.set_values(xtargetdata,yneigbourData)                
                    corr_relationship = self.similarity_func()
                    if(corr_relationship !="invalid_similarity"):
                        correlation_arr[user] = corr_relationship
                else:
                    pass
            else:
                pass

        if(len(correlation_arr)  < 1) :
            return "No similarity between users"
        else:
            correlation_df = pd.DataFrame.from_dict(correlation_arr, orient='index')
            correlation_df = correlation_df.sort_values([0], ascending=[False])
            return correlation_df.head(self.threshhold)

    def set_threshhold(self,threshold):
        self.threshhold = threshold
    def similarity_func(self):
        if self.__similarity_ == "squared_euclidean_similarity":
            return self.sim.squared_euclidean_similarity()
        elif self.__similarity_ == "minkowski_distance_similarity":
            return self.sim.minkowski_distance_similarity()
        elif self.__similarity_ == "hamming_distance_similarity":
            return self.sim.hamming_distance_similarity()
        elif self.__similarity_ == "cosine_similarity":
            return self.sim.cosine_similarity()
        elif self.__similarity_ == "spearman_correlation_similarity":
            return self.sim.spearman_correlation_similarity()
        elif self.__similarity_ == "pearson_correlation":
            return self.sim.pearson_correlation()
        elif self.__similarity_ == "chebyshev_similarity":
            return self.sim.chebyshev_similarity()
        else:
            return "invalid_similarity"
        


# In[ ]:




