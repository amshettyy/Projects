#!/usr/bin/env python
# coding: utf-8

# In[1]:


import pandas as pd
import numpy as np

class Loaddata:
    def __init__(self,file1,file2,file3):
        self.__file1 = file1
        self.__file2 = file2
        self.__file3 = file3
    def getbooks_data(self):
        booksdata = pd.read_csv(self.__file1,sep=';',usecols=[0,1,2])
        return booksdata
    def getbook_ratings(self):
        book_ratingsdata = pd.read_csv(self.__file2,sep=';', error_bad_lines=False)
        return book_ratingsdata
    def getusers(self):
        userdata = pd.read_csv(self.__file3,sep=';', error_bad_lines=False)
        return userdata
    def mergedataset(self):
        booksdata = self.getbooks_data()
        book_ratingsdata = self.getbook_ratings()
        alldata = pd.merge(book_ratingsdata,booksdata[['ISBN','Book-Title','Book-Author']], on='ISBN', how = 'inner')
        return alldata
        
    
    
    
        


# In[ ]:





# In[ ]:





# In[ ]:




