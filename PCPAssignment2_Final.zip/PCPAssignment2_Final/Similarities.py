#!/usr/bin/env python
# coding: utf-8

# In[17]:


import math
from scipy import spatial
import scipy.stats.stats as sc
import numpy as np

class Similarity:
    def __init__(self,x=None,y=None):
        self.__x=x
        self.__y=y
        
    def set_values(self,x,y):
        self.__x=x
        self.__y=y
    def get_values(self):
        return self.__x,self.__y
        
    def squared_euclidean_similarity(self):
        ecuval=spatial.distance.euclidean(self.__x,self.__y)
        sim=1/(1+ecuval)
        return sim
    
    def minkowski_distance_similarity(self,p=2):
        minkowski=spatial.distance.minkowski(self.__x,self.__y,p)
        return 1/(1+minkowski)
    
    def hamming_distance_similarity(self):
        hamming=spatial.distance.hamming(self.__x,self.__y)
        return 1/(1+hamming)
        
    def cosine_similarity(self):
        cosine=spatial.distance.cosine(self.__x,self.__y)
        return cosine
     
    def spearman_correlation_similarity(self):
        spearman=sc.spearmanr(self.__x,self.__y)[0]
        return spearman
           
    def pearson_correlation(self):
        pearson=sc.pearsonr(self.__x,self.__y)[0]
        return pearson

    def chebyshev_similarity(self):
        cheby=spatial.distance.chebyshev(self.__x,self.__y)
        return cheby
    

        


# In[ ]:




