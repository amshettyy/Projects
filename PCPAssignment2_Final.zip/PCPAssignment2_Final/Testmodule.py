#!/usr/bin/env python
# coding: utf-8

# In[1]:


import knn_module as knn
def main():
    import user_user as u
    import book_book as b
    print("############ Calculating Similarity ######################")
    print("Initializing Please Wait .. ")
    test = u.test_Module()
    book = b.BookSim()
    import Dataset_Module as dm
    mergerdataframe= dm.Loaddata("Books.csv","Book-Ratings.csv","Users.csv")
    mergerdataframe = mergerdataframe.mergedataset()
    print("Done !! ")
    print("####################################################")
    print("\n \rPlease Select a Similarity Type")
    print("\n \r1. Recommendations with User id")
    print("\n \r2. Recommendations with ISBN")
    similarity_type = input("Please enter Choice : ")
    if (similarity_type == "1"):
        test.set_dataframe(mergerdataframe)
        user_id = int(input("Please enter user id : "))
        arr = ["squared_euclidean_similarity","minkowski_distance_similarity","hamming_distance_similarity","cosine_similarity","spearman_correlation_similarity","pearson_correlation","chebyshev_similarity"]
        print("\n \rPlease select a similarity from below")
        print("##############################################")
        for i,val in enumerate(arr):
            print(i+1,".",val)
        sim = 100
        i = 0 
        while(sim > len(arr) or sim < 1):
            similarity = input("Similarity Number: ")
            if((similarity.isdecimal() == False)):
                print("Invalid Input enter a valid choice:")
                sim = 100
                i+=1
            else:
                if(i>0):
                    print("Invalid Input enter a valid choice:")
                sim = int(similarity)
        thresh = int(input("Enter Threshold: "))
        test.set_set_user(user_id)
        test.set_similarity(arr[int(sim)-1])
        test.set_threshhold(thresh)
        targrts_df = test.cal_similarusers_sim()
        print(targrts_df)
        ####################################################################
        ######################## KNN #######################################
        targrts_df.columns = ['similarity']
        targrts_df['User-ID'] = targrts_df.index
#         return targrts_df
        print(targrts_df)
        new_df = mergerdataframe[mergerdataframe['User-ID'].isin(targrts_df['User-ID'].tolist())]
        kn = knn.KNearestNeighbors()
        kn.set_values(new_df,mergerdataframe)
        print('Recomended Books for target user are:')
        return kn.knn_out()    
    
    elif(similarity_type == "2"):
        isbn = input("Please enter ISBN : ")
        arr = ["squared_euclidean_similarity","minkowski_distance_similarity","hamming_distance_similarity","cosine_similarity","spearman_correlation_similarity","pearson_correlation","chebyshev_similarity"]
        print("\n \rPlease select a similarity from below")
        print("##############################################")
        for i,val in enumerate(arr):
            print(i+1,".",val)
        sim = 10
        i = 0  
        while(sim > len(arr) or sim < 1):
            similarity = input("Similarity Number: ")
            if((similarity.isdecimal() == False)):
                print("Invalid Input enter a valid choice:")
                sim = 100
                i+=1
            else:
                if(i>0):
                    print("Invalid Input enter a valid choice:")
                sim = int(similarity)
        
        thresh = int(input("Enter Threshold: "))
        book.set_isbn(isbn)
        book.set_dataframe(mergerdataframe)
        book.set_similarity(arr[int(sim)-1])
        book.set_threshhold(thresh)
        return book.sort_and_present()
    else:
        print("\r \n\nInvalid Input Please Try again")
        main()
        


# In[2]:


main()


# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:





# In[ ]:




